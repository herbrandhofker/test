package academy.kafka.serializers;

import academy.kafka.serializers.examples.JsonPerson;
import java.util.HashMap;
import java.util.Map;
import org.apache.kafka.common.errors.SerializationException;
import org.junit.jupiter.api.Assertions;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class JsonSerializerTests {

    final static String topic = "dummy";

    @Test
    public void jsonTest() {
        Map<String, Object> configs = new HashMap<String, Object>();
        configs.put(JsonSerde.JSON_CLASS, JsonPerson.class);

        JsonSerializer<JsonPerson> serializer = new JsonSerializer<JsonPerson>();
        serializer.configure(configs, false);
        JsonDeserializer<JsonPerson> deserializer = new JsonDeserializer<JsonPerson>();
        deserializer.configure(configs, false);
        final JsonPerson source = new JsonPerson("BSNBSN", "Pietje", "Puk", "IBANIBAN");

        final byte[] data = serializer.serialize(topic, source);
        final JsonPerson result = deserializer.deserialize(topic, data);
        assertEquals(source.toString(), result.toString());
        serializer.close();
        deserializer.close();
        

    }

   @Test
    public void jsonNoConfigTest() {

        JsonSerializer<JsonPerson> serializer = new JsonSerializer<JsonPerson>();
        final JsonPerson source = new JsonPerson("BSNBSN", "Pietje", "Puk", "IBANIBAN");

        Assertions.assertThrows(SerializationException.class, () -> {
            serializer.serialize(topic, source);

        });
        serializer.close();
       
    }
/*
    @Test
    public void jsonNoConfig2Test() {
        Map<String, Object> configs = new HashMap<String, Object>();
        configs.put("JsonClass", JsonPerson.class);

        JsonSerializer<JsonPerson> serializer = new JsonSerializer<JsonPerson>();
        serializer.configure(configs, false);
        JsonDeserializer<JsonPerson> deserializer = new JsonDeserializer<JsonPerson>();
        final JsonPerson source = new JsonPerson("BSNBSN", "Pietje", "Puk", "IBANIBAN");
        final byte[] data = serializer.serialize(topic, source);

        Assertions.assertThrows(SerializationException.class, () -> {
            deserializer.deserialize(topic, data);

        });
        serializer.close();
        deserializer.close();       
    }

    //@Test
    public void jsonWrongClassTest() {
        Map<String, Object> configs = new HashMap<String, Object>();
        configs.put("JsonClass", Assertions.class);// wrong class

        JsonSerializer<JsonPerson> serializer = new JsonSerializer<JsonPerson>();
        serializer.configure(configs, false);
        JsonDeserializer<JsonPerson> deserializer = new JsonDeserializer<JsonPerson>();
        deserializer.configure(configs, false);

        final JsonPerson source = new JsonPerson("BSNBSN", "Pietje", "Puk", "IBANIBAN");

        final byte[] data = serializer.serialize(topic, source);

        Assertions.assertThrows(SerializationException.class, () -> {
            deserializer.deserialize(topic, data);

        });
        serializer.close();
        deserializer.close();
   
    }
    */
}
